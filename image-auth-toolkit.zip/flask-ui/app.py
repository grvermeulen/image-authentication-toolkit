
from flask import Flask, render_template_string, request
import requests
import os

app = Flask(__name__)
UPLOAD_FOLDER = './images'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

HTML = '''
<!doctype html>
<title>Image Authenticity Toolkit</title>
<h1>Upload Image for Analysis</h1>
<form method=post enctype=multipart/form-data>
  <input type=file name=file>
  <input type=submit value=Upload>
</form>
{% if filename %}
  <h2>Results for: {{ filename }}</h2>
  <img src="{{ url_for('static', filename='ela_' + filename) }}" height="300"><br>
{% endif %}
'''

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    filename = None
    if request.method == 'POST':
        f = request.files['file']
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], f.filename)
        f.save(filepath)
        requests.post('http://foto-forensics:5000/upload', files={'file': open(filepath, 'rb')})
        filename = f.filename
    return render_template_string(HTML, filename=filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
