
from flask import Flask, request, send_file
from PIL import Image, ImageChops, ImageEnhance
import os

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_image():
    f = request.files['file']
    path = f"./images/{f.filename}"
    f.save(path)

    im = Image.open(path).convert('RGB')
    im.save('temp.jpg', quality=95)
    temp = Image.open('temp.jpg')

    diff = ImageChops.difference(im, temp)
    diff = ImageEnhance.Brightness(diff).enhance(10)
    ela_path = f"./images/ela_{f.filename}"
    diff.save(ela_path)

    return send_file(ela_path, mimetype='image/jpeg')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
