#!/bin/bash
mkdir -p models
cd models
wget https://example.com/mantra-net-weights.pth
